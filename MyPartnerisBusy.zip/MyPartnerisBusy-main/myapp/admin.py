from django.contrib import admin
from .models import CallStatus,Visitor
# Register your models here.

admin.site.register(CallStatus)
admin.site.register(Visitor)
